<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<head>
<style>
table {
    border-collapse: collapse;
    width: 100%;
}

 td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
	text-align:center;
    background-color:#FF6;
    color:#F00;
	padding:20px;
}
</style>


<title>Rto admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<meta name="keywords" content="Road Way Underconstruction Responsive Templates, Iphone Widget Template, Smartphone login forms,Login form, Widget Template, Responsive Templates, a Ipad 404 Templates, Flat Responsive Templates" />
<!--css-->
<link rel="stylesheet" href="css/style.css" type="text/css">
<link rel="stylesheet" href="css/jquery.countdown.css" />
<!--/css-->
<!--js-->
<script src="js/jquery.min.js"></script>
<script src="js/jquery.countdown.js"></script>
<script src="js/script.js"></script>
<!--js-->
<!-- webfonts -->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700,800' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Monoton' rel='stylesheet' type='text/css'>
<!-- webfonts --> 
</head>
<body> 
<!----->
<div class="banner">
	<h1>RTO Admin Panel</h1>
		<div class="banner-text">
			<h2></h2>	
				<div class="timer_wrap">
					<div ><A href="index.php"><font color="#FFFF00">Home </font></div>	
                    	<form  method="post" name="form1">
.
    <table align="center" width="750">
  <tr><Th colspan="7" align="center">NEW USER APPLICATIONS</th>
	
    </tr>  <tr >
    <td > Name</td><td >Address</td>
<td >Email</td><td >Contact no</td><td>Image</td><td align="center" colspan="2">Action</td></tr>
<?php
		$con=mysqli_connect("localhost","root","");
mysqli_select_db($con,"pension");
$sql2="select * from userreg where status=0";
$res=mysqli_query($con,$sql2);
while($r=mysqli_fetch_array($res))
{
?>
 
<tr><td><?PHP echo $r[1];?></td>
 
     <td></td>
    <td><?PHP echo $r[2];?></td>

 <td></td>
    <td><?PHP echo $r[3];?></td>


	
    <td><?PHP echo $r[4];?> </td>
	
    <td><img src="../uploads/<?PHP echo $r[4];?> "></td>

<td align="center" colspan="2"><a href="sendmail/index.php?id=<?php echo $r[5];?>"><td align="center" colspan="2">
<a href="?id=<?php echo $r[5];?>"></a></td></tr>

<?php
}
?></table>

  
				</div> 	
				<div class="clear"> </div> 				
		</div>  
	
	</div>		
</div> 
<!----->
</body>
</html>