<?php
$email=$_POST['email'];
require 'PHPMailer/PHPMailerAutoload.php';

$mail = new PHPMailer;

$mail->isSMTP();                                   // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';                    // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                            // Enable SMTP authentication
$mail->Username = 'foreversonia@gmail.com';          // SMTP username
$mail->Password = 'sanujiju2015'; // SMTP password
$mail->SMTPSecure = 'tls';                         // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                                 // TCP port to connect to

$mail->setFrom('RTOadmin@gmail.com', 'RTO Administrator');
$mail->addReplyTo('RTOadmin@gmail.com', 'RTO Administrator');
$mail->addAddress($email);   // Add a recipient
//$mail->addCC('cc@example.com');
//$mail->addBCC('bcc@example.com');

$mail->isHTML(true);  // Set email format to HTML

$bodyContent = '<p>License Application Approved</p>'.$child;
$bodyContent .= '<p>License will get after 10 days.</p>';

$mail->Subject = 'Mail from kerala vehicle rto office';
$mail->Body    = $bodyContent;

if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo 'Message has been sent';
}
?>
