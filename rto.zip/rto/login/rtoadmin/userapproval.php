
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>


   </head>
   <body>             
        
				<form  method="post" name="form1">
.
    <table align="center" width="550">
  <tr><Th>NEW USER REQUESTS</th>
	
    </tr>  <tr bgcolor="#99CCFF" height="50">
    <td > Name</td><td >Address</td>
<td >Email</td><td >Contact no</td><td>Image</td></tr><?php
	include("../connection.php");
$ob=new connection();
$sql2="select * from userreg where status=0";
$res2=$ob->execute($sql2);
while($r=mysqli_fetch_array($res2))
{
?>
 
<tr><td><?PHP echo $r[1];?></td>
 
     <td></td>
    <td><?PHP echo $r[2];?></td>

 <td></td>
    <td><?PHP echo $r[3];?></td>


	
    <td><?PHP echo $r[4];?> </td>
	
    <td><img src="../uploads/<?PHP echo $r[4];?> "></td>

<td align="center" colspan="2"><a href="approveuser.php?id=<?php echo $r[5];?>"><td align="center" colspan="2">
<a href="rejectuser.php?id=<?php echo $r[5];?>"></a></td></tr>

<?php
}
?></table>

   <br><br><br>    
        <br><br><br>    
 <table align="center" width="550">
  <tr><td align="center" colspan="4">
 <font color="#0000FF"><b>REGISTERED USERS</td>
	
    </tr> <tr height="50" bgcolor="#CCCCCC"><td><b>Name</td><td><b>Address</td><td><b>Email</td><td><b>Contact no</td> 
    <td colspan="2" align="center">Actions</td></tr><?php
	$con=mysqli_connect("localhost","root","");
mysqli_select_db($con,"pension");
$sql2="select * from userreg where status=1";
$res=mysqli_query($con,$sql2);
while($r=mysqli_fetch_array($res2))
{
?>
 
<tr><td><?PHP echo $r[1];?></td>
 
    
    <td><?PHP echo $r[2];?></td>


    <td><?PHP echo $r[3];?></td>


	
    <td><?PHP echo $r[4];?> </td>
	
    

<?php
}
?></table>
</form>

</body>
</html>
