<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<head>
<title>Rto admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<meta name="keywords" content="Road Way Underconstruction Responsive Templates, Iphone Widget Template, Smartphone login forms,Login form, Widget Template, Responsive Templates, a Ipad 404 Templates, Flat Responsive Templates" />
<!--css-->
<link rel="stylesheet" href="css/style.css" type="text/css">
<link rel="stylesheet" href="css/jquery.countdown.css" />
<!--/css-->
<!--js-->
<script src="js/jquery.min.js"></script>
<script src="js/jquery.countdown.js"></script>
<script src="js/script.js"></script>
<!--js-->
<!-- webfonts -->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700,800' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Monoton' rel='stylesheet' type='text/css'>
<!-- webfonts --> 
</head>
<body> 
<!----->
<div class="banner">
	<h1>RTO Admin Panel</h1>
		<div class="banner-text">
			<h2>ISSUEING LICENSES FOR ALL TYPES OF VEHICLES</h2>	
				<div class="timer_wrap">
					<div ><A href="index.php"><font color="#FFFF00">Home </div>	
                    <div ><A href="view.php"><font color="#FFFF00">View applications</div>	
                    <div ><A href="../../logout.php"><font color="#FFFF00">Log out</div>		
				</div> 	
				<div class="clear"> </div> 				
		</div>  
	<div class="bottom-form">
		<div class="wrap">
			<div class="get-in">
				<h3>Get In Touch</h3>
				<p>Stay tuned and don't forget Sign up for latest Updates!</p>
				
			</div>
			<ul class="header-bottom">
				<p>Follow Us</p>
					<li><a href="#" class="facebook"> </a></li>
					<li><a href="#" class="twitter"> </a></li>
					<li><a href="#" class="gp"> </a></li>
					<li><a href="#" class="instagram"> </a></li>
					<li><a href="#" class="behance"> </a></li>
			</ul>
				<div class="tweets">
					<h5>LATEST APPLICATIONS</h5>
					<h6>Loading applications...</h6>
					<div class="copyrights">
						<p>Design by <a href="http://w3layouts.com">Logic</a></p>
					</div>
			    </div>
			    <div class="clear"> </div> 
		</div>
	</div>		
</div> 
<!----->
</body>
</html>