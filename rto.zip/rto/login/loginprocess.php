<?php 
session_start();
$u=$_POST['uname'];
$p=$_POST['psd'];
$con=mysqli_connect("localhost","root","");
mysqli_select_db($con,"");
$sql="select * from login where uname='$u' and pass='$p' and status=1";
$res=mysqli_query($con,$sql);

$r=mysqli_fetch_array($res);
		
		
		$_SESSION['uname']=$r[1];
		
		$_SESSION['id']=$r[0];
		
		
		
		if($r[3]=='rto')
		{*/
		header('location:rtoadmin/index.php');
		/*}
		
		else
		{
		echo "<script>
window.onload=function()
{
alert('Invalid username or password....!');
window.location='login.php';
}
</script>";


		}*/
?>